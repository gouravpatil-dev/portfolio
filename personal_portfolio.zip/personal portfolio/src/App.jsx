import { useEffect, useState } from 'react'
import { AnimatePresence, motion, useReducedMotion } from 'motion/react'
import {
  ArrowDownRight,
  ArrowUpRight,
  Code2,
  Command,
  Mail,
  Menu,
  Moon,
  Sparkles,
  Sun,
  X,
} from 'lucide-react'
import './App.css'

// Add real project objects here when ready - each renders as one card.
// Shape: { number: '01', name, description, stack: [...], tone: 'lime' | 'blue' | 'peach', status, href }
const projects = []

const navigation = [
  { label: 'work', href: '#work' },
  { label: 'about', href: '#about' },
  { label: 'stack', href: '#stack' },
]

const commandItems = [
  { label: 'See selected work', href: '#work', key: '1' },
  { label: 'Read about me', href: '#about', key: '2' },
  { label: 'Open my stack', href: '#stack', key: '3' },
  { label: 'Start a conversation', href: '#contact', key: '4' },
]

// Replace these three placeholders with your real contact details before publishing.
const contact = {
  email: 'your-email@example.com',
  github: 'https://github.com/your-github-handle',
  linkedin: 'https://www.linkedin.com/in/your-linkedin-handle',
}

const rise = {
  hidden: { opacity: 0, y: 20 },
  visible: (index = 0) => ({
    opacity: 1,
    y: 0,
    transition: {
      delay: 0.1 + index * 0.08,
      duration: 0.65,
      ease: [0.16, 1, 0.3, 1],
    },
  }),
}

function App() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [commandOpen, setCommandOpen] = useState(false)
  const [lightMode, setLightMode] = useState(false)
  const prefersReducedMotion = useReducedMotion()

  useEffect(() => {
    const handleKeyDown = (event) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') {
        event.preventDefault()
        setCommandOpen((open) => !open)
      }
      if (event.key === 'Escape') {
        setCommandOpen(false)
        setMenuOpen(false)
      }
    }

    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [])

  const closeMenus = () => {
    setCommandOpen(false)
    setMenuOpen(false)
  }

  return (
    <div className={`app ${lightMode ? 'is-light' : ''}`}>
      <div className="ambient ambient-one" aria-hidden="true" />
      <div className="ambient ambient-two" aria-hidden="true" />

      <header className="site-header shell">
        <a className="wordmark" href="#top" aria-label="Gourav home">
          <span className="wordmark-mark">g</span>
          <span>gourav.</span>
        </a>

        <nav className="desktop-nav" aria-label="Main navigation">
          {navigation.map((item) => (
            <a key={item.label} href={item.href}>
              {item.label}
            </a>
          ))}
        </nav>

        <div className="header-actions">
          <button
            className="icon-button theme-button"
            type="button"
            onClick={() => setLightMode((enabled) => !enabled)}
            aria-label={lightMode ? 'Switch to dark theme' : 'Switch to light theme'}
          >
            {lightMode ? <Moon size={16} /> : <Sun size={16} />}
          </button>
          <button
            className="command-trigger"
            type="button"
            onClick={() => setCommandOpen(true)}
            aria-label="Open quick navigation"
          >
            <Command size={14} />
            <span>menu</span>
            <kbd>⌘K</kbd>
          </button>
          <button
            className="menu-trigger"
            type="button"
            onClick={() => setMenuOpen((open) => !open)}
            aria-label={menuOpen ? 'Close menu' : 'Open menu'}
          >
            {menuOpen ? <X size={19} /> : <Menu size={20} />}
          </button>
        </div>
      </header>

      <AnimatePresence>
        {menuOpen && (
          <motion.nav
            className="mobile-nav shell"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.25 }}
            aria-label="Mobile navigation"
          >
            {navigation.map((item, index) => (
              <motion.a
                key={item.label}
                href={item.href}
                onClick={closeMenus}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.06 * index }}
              >
                <span>0{index + 1}</span>
                {item.label}
                <ArrowDownRight size={18} />
              </motion.a>
            ))}
          </motion.nav>
        )}
      </AnimatePresence>

      <main id="top">
        <section className="hero shell">
          <div className="hero-copy">
            <motion.div
              className="eyebrow availability"
              variants={rise}
              initial="hidden"
              animate="visible"
            >
              <span className="status-dot" />
              open to internships &amp; collaborations
            </motion.div>
            <motion.p
              className="hero-kicker"
              custom={1}
              variants={rise}
              initial="hidden"
              animate="visible"
            >
              // computer science student · builder
            </motion.p>
            <motion.h1
              custom={2}
              variants={rise}
              initial="hidden"
              animate="visible"
            >
              I turn curious ideas into <em>working</em> software.
            </motion.h1>
            <motion.p
              className="hero-intro"
              custom={3}
              variants={rise}
              initial="hidden"
              animate="visible"
            >
              I&apos;m Gourav - a Computer Science student at COEP Technological
              University, learning in public and building useful things along the way.
            </motion.p>
            <motion.div
              className="hero-cta-row"
              custom={4}
              variants={rise}
              initial="hidden"
              animate="visible"
            >
              <a className="shimmer-button" href="#work">
                <span>explore my work</span>
                <ArrowDownRight size={18} />
              </a>
              <a className="text-link" href="#contact">
                say hello <ArrowUpRight size={15} />
              </a>
            </motion.div>
          </div>

          <motion.aside
            className="profile-window"
            initial={prefersReducedMotion ? false : { opacity: 0, y: 28, rotate: 1.5 }}
            animate={{ opacity: 1, y: 0, rotate: 0 }}
            transition={{ delay: 0.25, duration: 0.85, ease: [0.16, 1, 0.3, 1] }}
            aria-label="Gourav developer profile"
          >
            <div className="window-titlebar">
              <div className="window-dots"><i /><i /><i /></div>
              <span>gourav.ts</span>
              <Code2 size={15} />
            </div>
            <div className="window-content">
              <p className="code-comment">// currently compiling a point of view</p>
              <pre>{`const gourav = {
  role: "cs_student",
  building: ["web", "systems"],
  learning: "one project at a time",
  energy: "curious",
  coffee: Infinity,
}`}</pre>
              <div className="window-footer">
                <span><b>●</b> all systems learning</span>
                <span>India · IST</span>
              </div>
            </div>
          </motion.aside>
        </section>

        <section className="quick-facts shell" aria-label="Quick facts">
          <div className="fact"><strong>COEP</strong><span>learning from<br />Pune, India</span></div>
          <div className="fact"><strong>∞</strong><span>ideas captured<br />and investigated</span></div>
          <div className="fact"><strong>01</strong><span>rule: ship, learn,<br />then improve</span></div>
          <a className="fact fact-link" href="#contact"><Sparkles size={18} /><span>let&apos;s make<br />something useful</span><ArrowUpRight size={17} /></a>
        </section>

        <section className="work-section shell" id="work">
          <motion.div
            className="section-heading"
            initial={prefersReducedMotion ? false : { opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.5 }}
          >
            <div>
              <p className="eyebrow">// selected work</p>
              <h2>Things I&apos;m building<br />to understand better.</h2>
            </div>
            <p className="section-note">A few experiments in translating<br />what I learn into something tangible.</p>
          </motion.div>

          {projects.length === 0 ? (
            <div className="project-empty">
              <span className="project-empty-dot" />
              <p>
                Projects are compiling. First real build lands here soon -
                until then, <a href="#stack">see what I&apos;m learning</a>.
              </p>
            </div>
          ) : (
          <div className="project-list">
            {projects.map((project, index) => (
              <motion.a
                className={`project-card ${project.tone}`}
                href="#contact"
                key={project.name}
                initial={prefersReducedMotion ? false : { opacity: 0, y: 22 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.15 }}
                transition={{ duration: 0.5, delay: index * 0.08 }}
                whileHover={prefersReducedMotion ? undefined : { y: -5 }}
              >
                <div className="project-topline">
                  <span>{project.number}</span>
                  <span className="project-status"><i /> {project.status}</span>
                  <ArrowUpRight className="project-arrow" size={19} />
                </div>
                <div className="project-art" aria-hidden="true">
                  {index === 0 && <><span className="bar bar-one" /><span className="bar bar-two" /><span className="bar bar-three" /><span className="bar bar-four" /><span className="chart-path" /></>}
                  {index === 1 && <><span className="orbit orbit-one" /><span className="orbit orbit-two" /><span className="project-node node-one" /><span className="project-node node-two" /><span className="project-node node-three" /></>}
                  {index === 2 && <><span className="post post-one">idea</span><span className="post post-two">ship</span><span className="post post-three">iterate</span></>}
                </div>
                <div className="project-body">
                  <h3>{project.name}</h3>
                  <p>{project.description}</p>
                  <ul>
                    {project.stack.map((tag) => <li key={tag}>{tag}</li>)}
                  </ul>
                </div>
              </motion.a>
            ))}
          </div>
          )}
        </section>

        <section className="about-section shell" id="about">
          <motion.div
            className="about-statement"
            initial={prefersReducedMotion ? false : { opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.25 }}
            transition={{ duration: 0.6 }}
          >
            <p className="eyebrow">// /now</p>
            <h2>I&apos;m in the phase where every good question becomes a project.</h2>
            <p>
              I enjoy the path from &ldquo;I wonder how that works&rdquo; to a small
              prototype you can click, test, break, and make better. Right now I&apos;m
              growing my foundations in computer science while exploring full-stack
              development, systems, and AI.
            </p>
            <a className="text-link" href="#stack">what I&apos;m learning <ArrowDownRight size={15} /></a>
          </motion.div>
          <div className="learning-grid">
            <div className="learning-card featured"><span>01</span><h3>Build in public</h3><p>Turning notes, lessons, and experiments into things that can help someone else.</p></div>
            <div className="learning-card"><span>02</span><h3>Think in systems</h3><p>Trying to understand the why beneath the code - not just the syntax.</p></div>
            <div className="learning-card"><span>03</span><h3>Stay curious</h3><p>Following threads that feel slightly out of reach, then doing the work to catch up.</p></div>
          </div>
        </section>

        <section className="stack-section shell" id="stack">
          <div className="terminal-window">
            <div className="terminal-header"><div className="window-dots"><i /><i /><i /></div><span>daily_stack.txt</span><span>◌</span></div>
            <div className="terminal-body">
              <p><span className="prompt">gourav@portfolio:~$</span> cat daily_stack.txt</p>
              <div className="stack-chips">
                {['C++', 'Python', 'JavaScript', 'React', 'Node.js', 'SQL', 'Git', 'DSA', 'Linux', 'Figma'].map((skill, index) => (
                  <motion.span
                    key={skill}
                    initial={prefersReducedMotion ? false : { opacity: 0, scale: 0.9 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.035, duration: 0.25 }}
                  >{skill}</motion.span>
                ))}
              </div>
              <p className="terminal-cursor"><span className="prompt">gourav@portfolio:~$</span> <b /></p>
            </div>
          </div>
          <div className="stack-copy">
            <p className="eyebrow">// growing toolkit</p>
            <h2>Tools are just tools. Knowing when to use them is the interesting part.</h2>
            <p>Each project is an excuse to get sharper at the fundamentals and add one considered tool to the kit.</p>
          </div>
        </section>
      </main>

      <footer className="site-footer shell" id="contact">
        <div className="footer-top">
          <p className="eyebrow">// let&apos;s build something</p>
          <h2>Have an idea worth<br />talking about?</h2>
          <a className="shimmer-button footer-button" href={`mailto:${contact.email}`}>
            <span>start a conversation</span><ArrowUpRight size={18} />
          </a>
        </div>
        <div className="footer-bottom">
          <div className="terminal-socials">
            <p>{'gourav@site:~$ find . -name "links" -exec cat {} \\;'}</p>
            <div>
              <a href={`mailto:${contact.email}`}><Mail size={16} /> email</a>
              <a href={contact.github} target="_blank" rel="noreferrer"><Code2 size={16} /> github</a>
              <a href={contact.linkedin} target="_blank" rel="noreferrer"><ArrowUpRight size={16} /> linkedin</a>
            </div>
          </div>
          <p className="copyright">© {new Date().getFullYear()} Gourav. Built with curiosity.</p>
        </div>
      </footer>

      <AnimatePresence>
        {commandOpen && (
          <motion.div
            className="command-backdrop"
            role="presentation"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onMouseDown={closeMenus}
          >
            <motion.div
              className="command-palette"
              role="dialog"
              aria-modal="true"
              aria-label="Quick navigation"
              initial={{ opacity: 0, y: -10, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -10, scale: 0.98 }}
              transition={{ duration: 0.2 }}
              onMouseDown={(event) => event.stopPropagation()}
            >
              <div className="palette-input"><Command size={17} /><span>Jump to a section</span><kbd>esc</kbd></div>
              <div className="palette-group-label">navigate</div>
              {commandItems.map((item) => (
                <a key={item.href} href={item.href} onClick={closeMenus} className="palette-item">
                  <span>{item.label}</span><kbd>{item.key}</kbd>
                </a>
              ))}
              <div className="palette-footer"><span>↑↓ to navigate</span><span>↵ to open</span></div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

export default App
