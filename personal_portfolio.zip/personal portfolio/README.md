# Gourav's portfolio

A responsive React portfolio with a dark developer aesthetic, a terminal-inspired profile card, Motion animations, and an accessible quick-navigation palette.

## Run locally

```bash
npm install
npm run dev
```

Then open the local address Vite prints in the terminal.

## Make it yours

- Replace the email, GitHub, and LinkedIn placeholders in [src/App.jsx](./src/App.jsx).
- Update the name, introductory copy, skills, and projects in that same file. The project data is grouped at the top.
- Add your resume or project image assets to `public/` when you have them.

## Checks

```bash
npm run build
npm run lint
```

The interface uses [Motion](https://motion.dev/) for the entrance, scroll, hover, and menu transitions. The shimmer action, command palette, bento cards, and dense dashboard-style layout take inspiration from the design patterns available on [21st.dev](https://21st.dev/).
